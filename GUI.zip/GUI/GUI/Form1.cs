﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace GUI
{

    public partial class Form1 : Form
    {
        private Process compiler = new Process();
        private String error;
        string openedFile;
        public Form1()
        {
            openedFile = null;
            compiler.StartInfo.FileName = System.Environment.CurrentDirectory + "\\c.exe";
            compiler.StartInfo.CreateNoWindow = true;
            compiler.StartInfo.UseShellExecute = false;
            compiler.StartInfo.RedirectStandardInput = true;
            compiler.StartInfo.RedirectStandardOutput = true;
            InitializeComponent();
            richTextBox2.BackColor = Color.White;
            timer1.Start();
        }


        private void timer1_Tick(object sender, EventArgs e)
        {   
            
            System.IO.File.WriteAllText("test.cpp", richTextBox1.Text);
            timer1.Stop();
            compiler.Start();
            compiler.StandardInput.WriteLine("temp.txt");
            while (compiler.HasExited == false) ;
            while (compiler.StandardOutput.Peek() != -1)
            {
                error = compiler.StandardOutput.ReadToEnd();
                
            }
            if (error.Length > 0)
            {
                if (error.StartsWith("\r\n")) {
                    richTextBox3.Text = error;
                    richTextBox2.Text = "Yaay no errors :D";
                    richTextBox2.ForeColor = Color.Green;
                }
                else {
                    string sep = "\r\n";
                    string symblTable=error.Substring(error.IndexOf(sep));
                    
                    richTextBox2.Text = error.Substring(0, error.Length - symblTable.Length);
                    richTextBox2.ForeColor = Color.Red;
                    if (symblTable.Length > 1) {
                        richTextBox3.Text = symblTable;
                    }
                    
                   }
             }
            timer1.Start();

        }


        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (openedFile == null)
            {
                saveFileDialog1.Title = "Save file";
                saveFileDialog1.ShowDialog();
                openedFile = saveFileDialog1.FileName;
                Form1.ActiveForm.Text = openedFile;
            }
            try
            {
                System.IO.File.WriteAllText(openedFile, richTextBox1.Text);
                saveFileDialog1.Title = "Output file";
                saveFileDialog1.ShowDialog();
                System.IO.File.WriteAllText("test.cpp", richTextBox1.Text);
                compiler.Start();
                compiler.StandardInput.WriteLine(saveFileDialog1.FileName);
                while (compiler.HasExited == false) ;
                while(compiler.StandardOutput.Peek()!=-1)
                    richTextBox2.Text = compiler.StandardOutput.ReadToEnd();
                while (compiler.HasExited == false) ;
                while (compiler.StandardOutput.Peek() != -1)
                {
                    error = compiler.StandardOutput.ReadToEnd();

                }
                if (error.Length > 0)
                {
                    if (error.StartsWith("\r\n"))
                    {
                        richTextBox3.Text = error;
                        richTextBox2.Text = "Yaay no errors :D";
                        richTextBox2.ForeColor = Color.Green;
                    }
                    else {
                        string sep = "\r\n";
                        string symblTable = error.Substring(error.IndexOf(sep));

                        richTextBox2.Text = error.Substring(0, error.Length - symblTable.Length);
                        richTextBox2.ForeColor = Color.Red;
                        if (symblTable.Length > 1)
                        {
                            richTextBox3.Text = symblTable;
                        }

                    }
                }

            }
            catch
            {

            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            openedFile = openFileDialog1.FileName;
            try
            {
                richTextBox1.Text = System.IO.File.ReadAllText(openedFile);
                Form1.ActiveForm.Text = openedFile;
            }
            catch
            {
            }
        }
    }
}
